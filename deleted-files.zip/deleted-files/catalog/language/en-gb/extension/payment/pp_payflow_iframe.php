<?php
// Text
$_['text_title']				= 'Credit or Debit Card';
$_['text_secure_connection']	= 'Creating a secure connection...';

// Error
$_['error_connection']			= 'Could not connect to PayPal. Please contact the shop\'s administrator for assistance or choose a different payment method.';